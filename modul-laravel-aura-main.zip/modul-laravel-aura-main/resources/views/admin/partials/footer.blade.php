<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright © 2022 Aura All rights reserved. Made by ❤️.
            </p>
        </div>
    </div>
</div>
